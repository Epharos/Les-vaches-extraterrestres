package fr.loubetrey;

public class Launcher 
{
	public static void main(String[] args)
	{
		@SuppressWarnings("unused")
		Game game = new Game();
	}
}
